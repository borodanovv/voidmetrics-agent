param(
  [string]$CoreUrl = "ws://127.0.0.1:3000/ws",
  [string]$Token = "paste-external-token-here",
  [switch]$Daemon
)

$env:VOIDMETRICS_CORE_URL = $CoreUrl
$env:VOIDMETRICS_AGENT_TOKEN = $Token
$Agent = Join-Path $PSScriptRoot "voidmetrics-agent.exe"

Write-Host "Starting VoidMetrics agent (external token)"
if ($Daemon) {
  & $Agent --daemon
} else {
  & $Agent
}
