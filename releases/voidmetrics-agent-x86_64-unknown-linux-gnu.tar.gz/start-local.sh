#!/usr/bin/env bash
set -euo pipefail

CORE_URL="${1:-ws://127.0.0.1:3000/ws}"
TOKEN="${2:-paste-local-token-here}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export VOIDMETRICS_CORE_URL="$CORE_URL"
export VOIDMETRICS_AGENT_TOKEN="$TOKEN"

echo "Starting VoidMetrics agent (local token)"
exec "$DIR/voidmetrics-agent" --daemon
